#ifndef EPSO_PARTICLE_H
#define EPSO_PARTICLE_H

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

#include "../cfGraph.h"

using namespace std;

constexpr int kHashLength = 300000;
constexpr int kVisitMax = 4;
constexpr double kLowerBound = -5.0;
constexpr double kUpperBound = 5.0;

// Deterministic Zobrist keys for compact state hashing.
static inline std::vector<std::uint64_t> g_zobrist;
static inline std::uint64_t SplitMix64(std::uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}
static inline void EnsureZobristTable(int n) {
    if (n <= 0 || static_cast<int>(g_zobrist.size()) >= n) return;
    const int old_size = static_cast<int>(g_zobrist.size());
    g_zobrist.resize(n);
    for (int i = old_size; i < n; ++i) {
        g_zobrist[i] = SplitMix64(0x123456789abcdef0ULL + static_cast<std::uint64_t>(i));
    }
}
static inline std::uint64_t ZobristKey(int v) {
    if (v < 0) v = -v;
    if (v >= 0 && v < static_cast<int>(g_zobrist.size())) return g_zobrist[v];
    return SplitMix64(0x123456789abcdef0ULL + static_cast<std::uint64_t>(v));
}
static inline std::uint64_t ZobristHash(const std::vector<int>& selected) {
    std::uint64_t h = 0;
    for (int v : selected) h ^= ZobristKey(v);
    return h;
}
static inline int HashSlot(const std::vector<int>& selected) {
    return static_cast<int>(ZobristHash(selected) % static_cast<std::uint64_t>(kHashLength));
}
static inline int HashSlot(std::uint64_t h) {
    return static_cast<int>(h % static_cast<std::uint64_t>(kHashLength));
}

static inline vector<int> SelectedFromPosition(const vector<double>& x) {
    vector<int> selected;
    selected.reserve(x.size());
    for (int i = 0; i < static_cast<int>(x.size()); ++i) {
        if (x[i] > 0.0) selected.push_back(i);
    }
    return selected;
}

static inline random_device g_random_device;
static inline mt19937 r_eng(g_random_device());
static inline uniform_real_distribution<double> disin(kLowerBound, kUpperBound);
static inline uniform_real_distribution<double> dis01(0.0, 1.0);
static inline uniform_real_distribution<double> dis_negative(kLowerBound, 0.0);
static inline uniform_real_distribution<double> dis_positive(1e-11, kUpperBound);

inline void set_seed(unsigned int seed) {
    r_eng.seed(seed);
}

inline int DecodeCoordinate(double x) {
    return x > 0.0 ? 1 : 0;
}

class Particle {
public:
    vector<double> number;      // continuous position X
    vector<int> numberb;        // decoded binary representation Y
    int fit = 0;                // current objective value
    int weight = 0;             // current total weight
    vector<int> selected;
    vector<int> candidates;

    int best_fit = 0;
    vector<double> number_best; // historical personal-best continuous position
    int best_weight = 0;
    int stay = 0;               // individual stagnation counter

    explicit Particle(int n) {
        number.reserve(n);
        numberb.reserve(n);
        for (int i = 0; i < n; ++i) {
            const double x = disin(r_eng);
            number.push_back(x);
            numberb.push_back(DecodeCoordinate(x));
        }
    }

    void getWeight(const cfGraph& cfg) {
        weight = 0;
        for (int v : selected) weight += cfg.originAdj[v].weight;
    }

    void getProfit(const cfGraph& cfg) {
        fit = 0;
        for (int v : selected) fit += cfg.originAdj[v].profit;
    }

    // Keep the continuous position and binary selection signs synchronized.
    void update(const cfGraph& cfg, int id, char op) {
        constexpr double eps = 1e-11;
        if (op == '-') {
            const double mag = std::max(eps, std::abs(number[id]));
            number[id] = -mag;
            numberb[id] = 0;
            weight -= cfg.originAdj[id].weight;
            fit -= cfg.originAdj[id].profit;
            candidates.push_back(id);
            auto it = std::remove(selected.begin(), selected.end(), id);
            selected.erase(it, selected.end());
        } else if (op == '+') {
            const double mag = std::max(eps, std::abs(number[id]));
            number[id] = mag;
            numberb[id] = 1;
            weight += cfg.originAdj[id].weight;
            fit += cfg.originAdj[id].profit;
            selected.push_back(id);
            auto it = std::remove(candidates.begin(), candidates.end(), id);
            candidates.erase(it, candidates.end());
        }
    }

    void DecodeAndEvaluate(const cfGraph& cfg) {
        numberb.clear();
        candidates.clear();
        selected.clear();
        weight = 0;
        fit = 0;
        numberb.reserve(number.size());
        for (int i = 0; i < static_cast<int>(number.size()); ++i) {
            const int bit = DecodeCoordinate(number[i]);
            numberb.push_back(bit);
            if (bit == 1) {
                selected.push_back(i);
                fit += cfg.originAdj[i].profit;
                weight += cfg.originAdj[i].weight;
            } else {
                candidates.push_back(i);
            }
        }
    }


    void InitializePersonalBest() {
        best_fit = fit;
        best_weight = weight;
        number_best = number;
    }


    void UpdatePersonalBest() {
        if (fit > best_fit || (fit == best_fit && weight < best_weight)) {
            best_fit = fit;
            best_weight = weight;
            number_best = number;
        }
    }

};

#endif // EPSO_PARTICLE_H
