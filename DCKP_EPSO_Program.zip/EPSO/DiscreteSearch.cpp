#include <algorithm>
#include <cstdint>
#include <limits>
#include <unordered_set>
#include <vector>

#include "SearchUtils.cpp"

using namespace std;

namespace {

struct ConflictIndex {
    const cfGraph& cfg;
    Particle& particle;
    vector<int> conflict_count;
    vector<char> in_selected;
    vector<int> zero_list;
    vector<int> zero_pos;

    ConflictIndex(const cfGraph& graph, Particle& p)
        : cfg(graph), particle(p), conflict_count(graph.n, 0), in_selected(graph.n, 0), zero_pos(graph.n, -1) {
        Rebuild();
    }

    void ZeroInsert(int v) {
        if (v < 0 || v >= cfg.n || in_selected[v] || conflict_count[v] != 0 || zero_pos[v] != -1) return;
        zero_pos[v] = static_cast<int>(zero_list.size());
        zero_list.push_back(v);
    }

    void ZeroErase(int v) {
        if (v < 0 || v >= cfg.n) return;
        const int pos = zero_pos[v];
        if (pos < 0) return;
        const int last = zero_list.back();
        zero_list[pos] = last;
        zero_pos[last] = pos;
        zero_list.pop_back();
        zero_pos[v] = -1;
    }

    void Rebuild() {
        fill(conflict_count.begin(), conflict_count.end(), 0);
        fill(in_selected.begin(), in_selected.end(), 0);
        for (int s : particle.selected) in_selected[s] = 1;
        for (int s : particle.selected) {
            for (int nb : cfg.originAdj[s].adjList) ++conflict_count[nb];
        }
        zero_list.clear();
        fill(zero_pos.begin(), zero_pos.end(), -1);
        for (int v = 0; v < cfg.n; ++v) {
            if (!in_selected[v] && conflict_count[v] == 0) ZeroInsert(v);
        }
    }

    void OnRemove(int id) {
        if (id < 0 || id >= cfg.n) return;
        in_selected[id] = 0;
        for (int nb : cfg.originAdj[id].adjList) {
            --conflict_count[nb];
            if (conflict_count[nb] == 0) ZeroInsert(nb);
        }
        ZeroInsert(id);
    }

    void OnAdd(int id) {
        if (id < 0 || id >= cfg.n) return;
        ZeroErase(id);
        in_selected[id] = 1;
        for (int nb : cfg.originAdj[id].adjList) {
            if (conflict_count[nb] == 0) ZeroErase(nb);
            ++conflict_count[nb];
        }
    }

    vector<int> ConflictingSelected() const {
        vector<int> out;
        for (int v : particle.selected) {
            if (conflict_count[v] > 0) out.push_back(v);
        }
        return out;
    }
};

vector<int> SampleWithoutReplacement(const vector<int>& source, int k) {
    if (source.empty() || k <= 0) return {};
    if (k >= static_cast<int>(source.size())) return source;
    vector<int> copy = source;
    for (int i = 0; i < k; ++i) {
        uniform_int_distribution<int> pick(i, static_cast<int>(copy.size()) - 1);
        const int j = pick(r_eng);
        std::swap(copy[i], copy[j]);
    }
    copy.resize(k);
    return copy;
}

int RandomArgMinAbs(const vector<int>& candidates, const Particle& p) {
    double best = numeric_limits<double>::infinity();
    vector<int> ties;
    for (int v : candidates) {
        const double score = std::abs(p.number[v]);
        if (score < best) {
            best = score;
            ties = {v};
        } else if (score == best) {
            ties.push_back(v);
        }
    }
    uniform_int_distribution<int> pick(0, static_cast<int>(ties.size()) - 1);
    return ties[pick(r_eng)];
}

int RandomArgMinAbsPerWeight(const vector<int>& candidates, const Particle& p, const cfGraph& cfg) {
    double best = numeric_limits<double>::infinity();
    vector<int> ties;
    for (int v : candidates) {
        const double score = std::abs(p.number[v]) / static_cast<double>(std::max(1, cfg.originAdj[v].weight));
        if (score < best) {
            best = score;
            ties = {v};
        } else if (score == best) {
            ties.push_back(v);
        }
    }
    uniform_int_distribution<int> pick(0, static_cast<int>(ties.size()) - 1);
    return ties[pick(r_eng)];
}

void UpdateBestEver(const Particle& candidate, Particle& best_ever) {
    if (candidate.fit > best_ever.fit ||
        (candidate.fit == best_ever.fit && candidate.weight < best_ever.weight)) {
        best_ever = candidate;
    }
}

} // namespace

// Restore conflict and capacity feasibility.
void RepairFeasibility(int capacity, const cfGraph& cfg, Particle& p, double rho) {
    ConflictIndex index(cfg, p);

    // Phase A: restore conflict feasibility.
    while (true) {
        vector<int> conflicting = index.ConflictingSelected();
        if (conflicting.empty()) break;

        const double u = dis01(r_eng);
        int drop_item = -1;
        if (u > rho) {
            drop_item = RandomArgMinAbs(conflicting, p);
        } else {
            uniform_int_distribution<int> pick(0, static_cast<int>(conflicting.size()) - 1);
            drop_item = conflicting[pick(r_eng)];
        }
        p.update(cfg, drop_item, '-');
        index.OnRemove(drop_item);
    }

    // Phase B: restore capacity feasibility.
    while (p.weight > capacity && !p.selected.empty()) {
        const double u = dis01(r_eng);
        int drop_item = -1;
        if (u > rho) {
            drop_item = RandomArgMinAbsPerWeight(p.selected, p, cfg);
        } else {
            uniform_int_distribution<int> pick(0, static_cast<int>(p.selected.size()) - 1);
            drop_item = p.selected[pick(r_eng)];
        }
        p.update(cfg, drop_item, '-');
        index.OnRemove(drop_item);
    }
}

// Improve a solution within the feasible region.
void FeasibleRegionImprove(int capacity,
                           const cfGraph& cfg,
                           Particle& p,
                           int max_iterations,
                           Particle& best_ever,
                           const vector<double>* long_term_base,
                           double long_term_scale,
                           double tau,
                           const vector<double>* topk_pw_sum) {
    constexpr int qmax = 2;
    int q = 0;
    int it = 0;

    Particle local_best = p;
    vector<int> short_term_frequency(cfg.n, 0);
    vector<unsigned char> visit(kHashLength, 0);
    std::uint64_t current_hash = ZobristHash(p.selected);
    visit[HashSlot(current_hash)] = 1;

    ConflictIndex index(cfg, p);

    auto RegisterMove = [&](const vector<int>& moved_items, std::uint64_t new_hash) {
        current_hash = new_hash;
        unsigned char& count = visit[HashSlot(current_hash)];
        if (count < 255) ++count;
        for (int v : moved_items) {
            if (v >= 0 && v < cfg.n) ++short_term_frequency[v];
        }
        p.UpdatePersonalBest();
    };

    auto RollBackToBest = [&]() {
        p = local_best;
        index.Rebuild();
        current_hash = ZobristHash(p.selected);
        visit[HashSlot(current_hash)] = std::max<unsigned char>(visit[HashSlot(current_hash)], 1);
    };

    while (it < max_iterations) {
        bool moved = false;
        const int sample_size = std::max(2, 8 - 2 * q);
        const double theta = AllowedDeterioration(q, cfg);
        const int residual = capacity - p.weight;

        // 1) Insertion.
        vector<int> insertion_candidates;
        insertion_candidates.reserve(index.zero_list.size());
        for (int v : index.zero_list) {
            if (cfg.originAdj[v].weight > residual) continue;
            const int new_fit = p.fit + cfg.originAdj[v].profit;
            const std::uint64_t h = current_hash ^ ZobristKey(v);
            if (visit[HashSlot(h)] < kVisitMax || new_fit > local_best.fit) {
                insertion_candidates.push_back(v);
            }
        }
        if (!insertion_candidates.empty()) {
            const vector<int> sampled = SampleWithoutReplacement(insertion_candidates,
                                                                 std::min(sample_size, static_cast<int>(insertion_candidates.size())));
            const int pos = SelectInsertionPoint(sampled, cfg, long_term_base, long_term_scale,
                                                 &short_term_frequency, tau);
            const int v = sampled[pos];
            const std::uint64_t h = current_hash ^ ZobristKey(v);
            p.update(cfg, v, '+');
            index.OnAdd(v);
            RegisterMove({v}, h);
            moved = true;
        }

        // 2) Exchange, only if insertion failed.
        if (!moved && !p.selected.empty()) {
            vector<int> removal_order = p.selected;
            shuffle(removal_order.begin(), removal_order.end(), r_eng);
            for (int u : removal_order) {
                vector<int> exchange_candidates;
                exchange_candidates.reserve(index.zero_list.size() + cfg.originAdj[u].adjList.size());

                for (int v = 0; v < cfg.n; ++v) {
                    if (v == u) continue;
                    if (index.in_selected[v]) continue;
                    const int conflicts_after = index.conflict_count[v] - (cfg.cfg[v][u] ? 1 : 0);
                    if (conflicts_after != 0) continue;
                    const int new_weight = p.weight - cfg.originAdj[u].weight + cfg.originAdj[v].weight;
                    if (new_weight > capacity) continue;
                    const int new_fit = p.fit - cfg.originAdj[u].profit + cfg.originAdj[v].profit;
                    if (static_cast<double>(local_best.fit - new_fit) > theta) continue;
                    const std::uint64_t h = current_hash ^ ZobristKey(u) ^ ZobristKey(v);
                    if (visit[HashSlot(h)] < kVisitMax || new_fit > local_best.fit) {
                        exchange_candidates.push_back(v);
                    }
                }

                if (exchange_candidates.empty()) continue;
                const vector<int> sampled = SampleWithoutReplacement(exchange_candidates,
                                                                     std::min(sample_size, static_cast<int>(exchange_candidates.size())));
                const int pos = SelectInsertionPoint(sampled, cfg, long_term_base, long_term_scale,
                                                     &short_term_frequency, tau);
                const int v = sampled[pos];
                const std::uint64_t h = current_hash ^ ZobristKey(u) ^ ZobristKey(v);
                p.update(cfg, u, '-');
                index.OnRemove(u);
                p.update(cfg, v, '+');
                index.OnAdd(v);
                RegisterMove({u, v}, h);
                moved = true;
                break;
            }
        }

        // 3) Deletion, only if insertion and exchange failed.
        if (!moved && !p.selected.empty()) {
            vector<int> deletion_candidates;
            deletion_candidates.reserve(p.selected.size());
            for (int u : p.selected) {
                const int new_fit = p.fit - cfg.originAdj[u].profit;
                if (static_cast<double>(local_best.fit - new_fit) > theta) continue;
                const std::uint64_t h = current_hash ^ ZobristKey(u);
                if (visit[HashSlot(h)] < kVisitMax || new_fit > local_best.fit) {
                    deletion_candidates.push_back(u);
                }
            }
            if (!deletion_candidates.empty()) {
                const vector<int> sampled = SampleWithoutReplacement(deletion_candidates,
                                                                     std::min(sample_size, static_cast<int>(deletion_candidates.size())));
                const int pos = SelectDeletionPoint(sampled, cfg, long_term_base, long_term_scale,
                                                    &short_term_frequency, tau, topk_pw_sum);
                const int u = sampled[pos];
                const std::uint64_t h = current_hash ^ ZobristKey(u);
                p.update(cfg, u, '-');
                index.OnRemove(u);
                RegisterMove({u}, h);
                moved = true;
            }
        }

        if (!moved) {
            ++q;
            RollBackToBest();
            if (q > qmax) break;
            continue;
        }

        if (p.fit > local_best.fit) {
            local_best = p;
            UpdateBestEver(local_best, best_ever);
            q = 0;
            it = 0;
        } else {
            ++it;
        }
    }

    UpdateBestEver(local_best, best_ever);
}

// Explore a controlled band around the capacity boundary.
void StrategicBoundaryOscillation(int capacity,
                                  const cfGraph& cfg,
                                  Particle& p,
                                  int max_iterations,
                                  Particle& best_ever) {
    ConflictIndex index(cfg, p);
    std::uint64_t current_hash = ZobristHash(p.selected);
    vector<unsigned char> visit(kHashLength, 0);
    visit[HashSlot(current_hash)] = 1;

    int minw = cfg.minw;
    int maxw = cfg.maxw;
    if (minw == numeric_limits<int>::max()) {
        minw = numeric_limits<int>::max();
        maxw = 0;
        for (int v = 0; v < cfg.n; ++v) {
            minw = std::min(minw, cfg.originAdj[v].weight);
            maxw = std::max(maxw, cfg.originAdj[v].weight);
        }
        if (minw == numeric_limits<int>::max()) minw = 0;
    }

    int CL1 = std::max(0, (minw + maxw) / 2);
    int CL2 = 0;
    constexpr int history_length = 100;
    vector<unsigned char> history(history_length, 0);
    int history_pos = 0;
    int history_fill = 0;
    int infeasible_count = 0;

    auto CV = [&](int weight) { return std::max(0, weight - capacity); };
    auto PushHistory = [&](bool infeasible) {
        const unsigned char value = infeasible ? 1 : 0;
        if (history_fill < history_length) {
            history[history_pos] = value;
            infeasible_count += value;
            ++history_fill;
        } else {
            infeasible_count -= history[history_pos];
            history[history_pos] = value;
            infeasible_count += value;
        }
        history_pos = (history_pos + 1) % history_length;
    };
    auto UpdateBounds = [&]() {
        if (history_fill < history_length) return;
        if (infeasible_count == 0) {
            CL2 = std::min(CL2 + 1, CL1);
        } else if (infeasible_count == history_length) {
            CL1 = std::max(CL1 - 1, 0);
            CL2 = std::min(CL2, CL1);
        }
    };

    Particle best_feasible = p;

    struct Move {
        int type = -1; // 0 add, 1 exchange, 2 delete
        int in_item = -1;
        int out_item = -1;
        int weight = 0;
        int fit = 0;
        int cv = 0;
        std::uint64_t hash = 0;
    };

    auto Better = [](const Move& a, const Move& b) {
        if (a.cv != b.cv) return a.cv < b.cv;
        return a.fit > b.fit;
    };

    for (int iter = 0; iter < max_iterations; ++iter) {
        UpdateBounds();
        const bool CL2_active = (history_fill == history_length && infeasible_count == 0);
        vector<Move> best_moves;

        auto Consider = [&](const Move& cand) {
            if (cand.cv > CL1) return;
            if (CL2_active && cand.cv < CL2) return;
            if (visit[HashSlot(cand.hash)] >= kVisitMax) return;
            if (best_moves.empty() || Better(cand, best_moves.front())) {
                best_moves.clear();
                best_moves.push_back(cand);
            } else if (!Better(best_moves.front(), cand) && !Better(cand, best_moves.front())) {
                best_moves.push_back(cand);
            }
        };

        // Add states: sample at most 300 items from Z(S).
        const vector<int> add_sample = SampleWithoutReplacement(index.zero_list,
                                                                 std::min(300, static_cast<int>(index.zero_list.size())));
        for (int v : add_sample) {
            Move cand;
            cand.type = 0;
            cand.in_item = v;
            cand.weight = p.weight + cfg.originAdj[v].weight;
            cand.fit = p.fit + cfg.originAdj[v].profit;
            cand.cv = CV(cand.weight);
            cand.hash = current_hash ^ ZobristKey(v);
            Consider(cand);
        }

        // Exchange states: sample at most 30 selected items, and for each at most
        // 150 items from Z(S \ {u}).
        const vector<int> out_sample = SampleWithoutReplacement(p.selected,
                                                                 std::min(30, static_cast<int>(p.selected.size())));
        for (int u : out_sample) {
            vector<int> z_after_removal = index.zero_list;
            z_after_removal.reserve(index.zero_list.size() + cfg.originAdj[u].adjList.size());
            for (int v : cfg.originAdj[u].adjList) {
                if (v == u || index.in_selected[v]) continue;
                if (index.conflict_count[v] == 1) z_after_removal.push_back(v);
            }
            const vector<int> in_sample = SampleWithoutReplacement(z_after_removal,
                                                                    std::min(150, static_cast<int>(z_after_removal.size())));
            for (int v : in_sample) {
                if (v == u) continue;
                Move cand;
                cand.type = 1;
                cand.in_item = v;
                cand.out_item = u;
                cand.weight = p.weight - cfg.originAdj[u].weight + cfg.originAdj[v].weight;
                cand.fit = p.fit - cfg.originAdj[u].profit + cfg.originAdj[v].profit;
                cand.cv = CV(cand.weight);
                cand.hash = current_hash ^ ZobristKey(u) ^ ZobristKey(v);
                Consider(cand);
            }
        }

        // Delete states only while overweight.
        if (CV(p.weight) > 0) {
            const vector<int> drop_sample = SampleWithoutReplacement(p.selected,
                                                                      std::min(30, static_cast<int>(p.selected.size())));
            for (int u : drop_sample) {
                Move cand;
                cand.type = 2;
                cand.out_item = u;
                cand.weight = p.weight - cfg.originAdj[u].weight;
                cand.fit = p.fit - cfg.originAdj[u].profit;
                cand.cv = CV(cand.weight);
                cand.hash = current_hash ^ ZobristKey(u);
                Consider(cand);
            }
        }

        if (best_moves.empty()) break;
        uniform_int_distribution<int> choose(0, static_cast<int>(best_moves.size()) - 1);
        const Move move = best_moves[choose(r_eng)];

        current_hash = move.hash;
        if (move.type == 0) {
            p.update(cfg, move.in_item, '+');
            index.OnAdd(move.in_item);
        } else if (move.type == 1) {
            p.update(cfg, move.out_item, '-');
            index.OnRemove(move.out_item);
            p.update(cfg, move.in_item, '+');
            index.OnAdd(move.in_item);
        } else {
            p.update(cfg, move.out_item, '-');
            index.OnRemove(move.out_item);
        }
        unsigned char& count = visit[HashSlot(current_hash)];
        if (count < 255) ++count;
        PushHistory(p.weight > capacity);

        // SOS may temporarily move through capacity-infeasible states. Only a
        // feasible state may update the particle's historical best or the
        // best feasible solution retained by the oscillation procedure.
        if (p.weight <= capacity) {
            p.UpdatePersonalBest();

            if (p.fit > best_feasible.fit) {
                best_feasible = p;
                CL2 = 0;
                UpdateBestEver(best_feasible, best_ever);
            }
        }
    }

    p = best_feasible;
    UpdateBestEver(best_feasible, best_ever);
}
