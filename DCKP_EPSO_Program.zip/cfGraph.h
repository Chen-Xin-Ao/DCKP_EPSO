#ifndef EPSO_CFGRAPH_H
#define EPSO_CFGRAPH_H

#include "Adjm.h"

#include <algorithm>
#include <limits>
#include <vector>

using namespace std;

class cfGraph {
public:
    int** cfg = nullptr;
    int n = 0;
    int minw = std::numeric_limits<int>::max();
    int maxw = 0;
    double avgp = 0.0;
    double midp = 0.0;
    double q1p = 0.0;
    double q3p = 0.0;
    double minp = 0.0;
    double maxp = 0.0;
    double density = 0.0;
    vector<Vertex> originAdj;
    vector<double> topk_pw_sum;

    cfGraph(int n_, double avg_profit, double min_profit, double max_profit,
            double q1_profit, double median_profit, double q3_profit)
        : n(n_), avgp(avg_profit), midp(median_profit), q1p(q1_profit), q3p(q3_profit),
          minp(min_profit), maxp(max_profit) {
        cfg = new int*[n];
        for (int i = 0; i < n; ++i) {
            cfg[i] = new int[n];
            for (int j = 0; j < n; ++j) cfg[i][j] = (i == j) ? 1 : 0;
        }
    }

    cfGraph(const cfGraph&) = delete;
    cfGraph& operator=(const cfGraph&) = delete;

    void getDensity(double ds) { density = ds; }

    void getVertices(vector<Vertex> vertices) {
        for (Vertex& v : vertices) {
            const double degree_factor = static_cast<double>(v.degree + 1);
            v.pwd = v.pw / degree_factor;
            v.wd = static_cast<double>(v.weight) * degree_factor;
            v.pd = static_cast<double>(v.profit) / degree_factor;
        }
        originAdj = std::move(vertices);

        // Npw(v) is the sum of the K largest neighbor pw values,
        // where K = max(1, floor(n/100)).
        const int k = std::max(1, n / 100);
        topk_pw_sum.assign(n, 0.0);
        for (int v = 0; v < n; ++v) {
            vector<double> values;
            values.reserve(originAdj[v].adjList.size());
            for (int nb : originAdj[v].adjList) values.push_back(originAdj[nb].pw);
            std::sort(values.begin(), values.end(), std::greater<double>());
            const int count = std::min(k, static_cast<int>(values.size()));
            for (int i = 0; i < count; ++i) topk_pw_sum[v] += values[i];
        }
    }

    void addEdges(int u, int v) {
        cfg[u][v] = 1;
        cfg[v][u] = 1;
    }

    void release() {
        if (!cfg) return;
        for (int i = 0; i < n; ++i) delete[] cfg[i];
        delete[] cfg;
        cfg = nullptr;
    }

    ~cfGraph() { release(); }
};

#endif // EPSO_CFGRAPH_H
