#include <vector>
#include "Particle.h"

using namespace std;

// Sample each particle independently in the continuous domain and decode it
// before feasibility repair.
vector<Particle> InitializePopulation(int population_size, const cfGraph& cfg) {
    vector<Particle> particles;
    particles.reserve(population_size);
    for (int i = 0; i < population_size; ++i) {
        Particle particle(cfg.n);
        particle.DecodeAndEvaluate(cfg);
        particle.stay = 0;
        particles.push_back(std::move(particle));
    }
    return particles;
}
