#include "Particle.h"
#include "Initialization.cpp"
#include "DiscreteSearch.cpp"
#include "RecoveryUtils.cpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <unordered_set>
#include <vector>

using namespace std;

double g_best_time = 0.0;

namespace {

struct PsoCoefficients {
    double w;
    double c1;
    double c2;
    double vmax;
};

PsoCoefficients PsoFromStay(int stay) {
    const double phi = std::min(1.0, std::max(0.0, static_cast<double>(stay) / 100.0));
    return {
        0.40 + phi * (0.90 - 0.40),
        2.20 - phi * (2.20 - 0.80),
        0.80 + phi * (2.20 - 0.80),
        0.20 + phi * (2.00 - 0.20)
    };
}

double TauFromStay(int stay) {
    const double phi = std::min(1.0, std::max(0.0, static_cast<double>(stay) / 100.0));
    return 0.20 + phi * (1.20 - 0.20);
}

void ClampPosition(vector<double>& x) {
    for (double& value : x) {
        if (!std::isfinite(value)) {
            value = disin(r_eng);
        } else {
            value = std::clamp(value, kLowerBound, kUpperBound);
        }
    }
}

const vector<double>& SelectFarthestGlobalBest(const vector<Particle>& global_best_states,
                                               const vector<double>& fallback,
                                               const vector<double>& current) {
    if (global_best_states.empty()) return fallback;
    int best_index = 0;
    double best_distance = -1.0;
    for (int i = 0; i < static_cast<int>(global_best_states.size()); ++i) {
        if (global_best_states[i].number.size() != current.size()) continue;
        double distance = 0.0;
        for (int d = 0; d < static_cast<int>(current.size()); ++d) {
            const double delta = global_best_states[i].number[d] - current[d];
            distance += delta * delta;
        }
        if (distance > best_distance) {
            best_distance = distance;
            best_index = i;
        }
    }
    return global_best_states[best_index].number;
}

void FeedbackAccepted(vector<double>& velocity,
                      const vector<double>& pre_refinement,
                      const vector<double>& post_refinement,
                      int updated_stay) {
    const PsoCoefficients coef = PsoFromStay(updated_stay);
    for (int d = 0; d < static_cast<int>(velocity.size()); ++d) {
        velocity[d] = 0.3 * velocity[d] + 0.7 * (post_refinement[d] - pre_refinement[d]);
        velocity[d] = std::clamp(velocity[d], -coef.vmax, coef.vmax);
    }
}

void FeedbackRejected(vector<double>& velocity,
                      const vector<double>& pre_refinement,
                      const vector<double>& rejected_candidate,
                      int updated_stay) {
    const PsoCoefficients coef = PsoFromStay(updated_stay);
    for (int d = 0; d < static_cast<int>(velocity.size()); ++d) {
        velocity[d] = 0.3 * velocity[d] - 0.14 * (rejected_candidate[d] - pre_refinement[d]);
        velocity[d] = std::clamp(velocity[d], -coef.vmax, coef.vmax);
    }
}

bool BetterSolution(const Particle& a, const Particle& b) {
    return a.fit > b.fit || (a.fit == b.fit && a.weight < b.weight);
}

} // namespace

vector<Particle> RunEPSO(int capacity,
                         const cfGraph& cfg,
                         int population_size,
                         double time_limit_sec,
                         int& completed_iterations) {
    using Clock = std::chrono::steady_clock;
    const auto start_time = Clock::now();
    g_best_time = 0.0;
    completed_iterations = 0;

    const int n = cfg.n;
    EnsureZobristTable(n);

    vector<Particle> particles = InitializePopulation(population_size, cfg);
    for (Particle& p : particles) {
        p.stay = 0;
        RepairFeasibility(capacity, cfg, p, RepairControlProbability(p.stay));
        p.InitializePersonalBest();
    }

    Particle global_best = particles.front();
    for (const Particle& p : particles) {
        if (BetterSolution(p, global_best)) global_best = p;
    }

    vector<Particle> global_best_states{global_best};
    unordered_set<std::uint64_t> global_best_hashes{ZobristHash(global_best.selected)};

    // Population-wide state history used by the stagnation counter.
    vector<unsigned char> population_history(kHashLength, 0);
    for (const Particle& p : particles) population_history[HashSlot(p.selected)] = 1;

    vector<vector<double>> velocity(particles.size(), vector<double>(n, 0.0));
    vector<vector<double>> pbest_position(particles.size());
    vector<int> pbest_fit(particles.size(), 0);
    vector<int> pbest_weight(particles.size(), 0);
    for (int i = 0; i < static_cast<int>(particles.size()); ++i) {
        pbest_position[i] = particles[i].number_best;
        pbest_fit[i] = particles[i].best_fit;
        pbest_weight[i] = particles[i].best_weight;
    }

    // Lazy representation of the individual-specific long-term frequency memories.
    // Effective F_i^L(v) = freq_base[i][v] * freq_scale[i].
    constexpr double alpha = 0.95;
    vector<vector<double>> freq_base(particles.size(), vector<double>(n, 0.0));
    vector<double> freq_scale(particles.size(), 1.0);

    auto ObserveRejectedCandidate = [&](int i, const vector<int>& selected) {
        const double inv_scale = 1.0 / std::max(1e-12, freq_scale[i]);
        for (int v : selected) {
            if (v >= 0 && v < n) freq_base[i][v] += inv_scale;
        }
    };
    auto DecayLongTermMemory = [&]() {
        for (int i = 0; i < static_cast<int>(freq_scale.size()); ++i) {
            freq_scale[i] *= alpha;
            if (freq_scale[i] < 1e-120) {
                for (double& f : freq_base[i]) f *= freq_scale[i];
                freq_scale[i] = 1.0;
            }
        }
    };

    auto Elapsed = [&]() {
        return std::chrono::duration<double>(Clock::now() - start_time).count();
    };

    cout << "GlobalBestProfit = " << global_best.fit
         << ", GlobalBestWeight = " << global_best.weight
         << ", Time = " << fixed << setprecision(3) << Elapsed() << endl;
    g_best_time = std::min(Elapsed(), time_limit_sec);

    int c_no_imp = 0;
    double last_improve_time = g_best_time;
    double last_perturb_time = 0.0;
    bool population_expanded = false;

    for (int generation = 0; ; ++generation) {
        if (Elapsed() >= time_limit_sec) {
            completed_iterations = generation;
            break;
        }

        bool objective_improved_this_generation = false;
        const int fri_max = (n / 500 + 5) * 250 + c_no_imp * (n / 500);
        const int sos_max = fri_max / 2;

        for (int i = 0; i < static_cast<int>(particles.size()); ++i) {
            if (Elapsed() >= time_limit_sec) break;

            Particle candidate = particles[i];
            const vector<double> pre_refinement_position = particles[i].number;
            const vector<double>& current_position = particles[i].number;
            const vector<double>& social_attractor = SelectFarthestGlobalBest(global_best_states,
                                                                               global_best.number,
                                                                               current_position);

            const PsoCoefficients coef = PsoFromStay(particles[i].stay);
            const double tau = TauFromStay(particles[i].stay);
            vector<double> proposal(n);
            for (int d = 0; d < n; ++d) {
                const double r1 = dis01(r_eng);
                const double r2 = dis01(r_eng);
                double v = coef.w * velocity[i][d]
                         + coef.c1 * r1 * (pbest_position[i][d] - current_position[d])
                         + coef.c2 * r2 * (social_attractor[d] - current_position[d]);
                velocity[i][d] = std::clamp(v, -coef.vmax, coef.vmax);
                proposal[d] = current_position[d] + velocity[i][d];
            }
            ClampPosition(proposal);

            ApplyPGSA(proposal, particles, c_no_imp);
            candidate.number = proposal;
            candidate.DecodeAndEvaluate(cfg);

            RepairFeasibility(capacity, cfg, candidate, RepairControlProbability(particles[i].stay));
            FeasibleRegionImprove(capacity, cfg, candidate, fri_max, global_best,
                                  &freq_base[i], freq_scale[i], tau, &cfg.topk_pw_sum);

            if (particles[i].stay > (15 * 2000 / std::max(1, n)) && dis01(r_eng) > 0.25) {
                StrategicBoundaryOscillation(capacity, cfg, candidate, sos_max, global_best);
            }

            const bool accepted = AcceptRefinedCandidate(particles[i].fit,
                                                         candidate.fit,
                                                         particles[i].best_fit,
                                                         particles[i].stay,
                                                         cfg);

            if (accepted) {
                particles[i].number = candidate.number;
                particles[i].DecodeAndEvaluate(cfg);

                const int slot = HashSlot(particles[i].selected);
                if (population_history[slot] == 0) {
                    population_history[slot] = 1;
                    particles[i].stay = 0;
                } else {
                    ++particles[i].stay;
                }
                FeedbackAccepted(velocity[i], pre_refinement_position, particles[i].number, particles[i].stay);
            } else {
                ObserveRejectedCandidate(i, candidate.selected);
                ++particles[i].stay;
                FeedbackRejected(velocity[i], pre_refinement_position, candidate.number, particles[i].stay);
            }

            // Update the individual's historical best from any improved state found during refinement.
            if (candidate.best_fit > particles[i].best_fit ||
                (candidate.best_fit == particles[i].best_fit && candidate.best_weight < particles[i].best_weight)) {
                particles[i].best_fit = candidate.best_fit;
                particles[i].best_weight = candidate.best_weight;
                particles[i].number_best = candidate.number_best;
                pbest_fit[i] = candidate.best_fit;
                pbest_weight[i] = candidate.best_weight;
                pbest_position[i] = candidate.number_best;
            } else if (particles[i].fit > pbest_fit[i] ||
                       (particles[i].fit == pbest_fit[i] && particles[i].weight < pbest_weight[i])) {
                pbest_fit[i] = particles[i].fit;
                pbest_weight[i] = particles[i].weight;
                pbest_position[i] = particles[i].number;
                particles[i].best_fit = pbest_fit[i];
                particles[i].best_weight = pbest_weight[i];
                particles[i].number_best = pbest_position[i];
            }

            if (global_best.fit > global_best_states.front().fit) {
                global_best_states.clear();
                global_best_hashes.clear();
                global_best_states.push_back(global_best);
                global_best_hashes.insert(ZobristHash(global_best.selected));
                objective_improved_this_generation = true;
                c_no_imp = 0;
                last_improve_time = std::min(Elapsed(), time_limit_sec);
                g_best_time = last_improve_time;
                cout << "GlobalBestProfit = " << global_best.fit
                     << ", GlobalBestWeight = " << global_best.weight
                     << ", Time = " << fixed << setprecision(3) << g_best_time << endl;
            } else if (global_best.fit == global_best_states.front().fit) {
                const std::uint64_t h = ZobristHash(global_best.selected);
                if (!global_best_hashes.count(h)) {
                    global_best_hashes.insert(h);
                    global_best_states.push_back(global_best);
                }
                if (global_best.weight < global_best_states.front().weight) {
                    global_best_states.front() = global_best;
                }
            }
        }

        DecayLongTermMemory();

        if (!objective_improved_this_generation) ++c_no_imp;

        const double now = std::min(Elapsed(), time_limit_sec);
        const double stagnation = now - last_improve_time;
        const double time_since_last_perturb = now - last_perturb_time;

        // Local perturbation is activated only after prolonged global
        // non-improvement and only if the same minimum interval has elapsed
        // since the previous local perturbation.
        if (!particles.empty() &&
            stagnation >= 0.1 * time_limit_sec &&
            time_since_last_perturb >= 0.1 * time_limit_sec) {
            int max_stay = particles.front().stay;
            for (const Particle& p : particles) max_stay = std::max(max_stay, p.stay);
            vector<int> candidates;
            for (int i = 0; i < static_cast<int>(particles.size()); ++i) {
                if (particles[i].stay == max_stay) candidates.push_back(i);
            }
            uniform_int_distribution<int> pick(0, static_cast<int>(candidates.size()) - 1);
            const int idx = candidates[pick(r_eng)];

            const vector<double> population_frequency = AggregateLongTermFrequency(freq_base, freq_scale, n);
            PerturbByInverseSet(particles[idx], population_frequency);
            particles[idx].DecodeAndEvaluate(cfg);
            particles[idx].stay = 0;
            RepairFeasibility(capacity, cfg, particles[idx], RepairControlProbability(0));
            velocity[idx].assign(n, 0.0);
            population_history[HashSlot(particles[idx].selected)] = 1;
            last_perturb_time = std::min(Elapsed(), time_limit_sec);
        }

        if (!population_expanded && stagnation >= 0.5 * time_limit_sec && !particles.empty()) {
            population_expanded = true;
            const int number_to_add = static_cast<int>(particles.size()) / 2;
            const vector<double> population_frequency = AggregateLongTermFrequency(freq_base, freq_scale, n);

            for (int k = 0; k < number_to_add; ++k) {
                Particle new_particle(n);
                new_particle.number = GenerateExpansionPosition(particles, population_frequency);
                new_particle.DecodeAndEvaluate(cfg);
                new_particle.stay = 0;
                RepairFeasibility(capacity, cfg, new_particle, RepairControlProbability(0));
                new_particle.InitializePersonalBest();

                particles.push_back(new_particle);
                velocity.push_back(vector<double>(n, 0.0));
                pbest_position.push_back(new_particle.number_best);
                pbest_fit.push_back(new_particle.best_fit);
                pbest_weight.push_back(new_particle.best_weight);
                freq_base.push_back(vector<double>(n, 0.0));
                freq_scale.push_back(1.0);
                population_history[HashSlot(new_particle.selected)] = 1;
            }
        }
    }

    if (global_best_states.empty()) global_best_states.push_back(global_best);
    return global_best_states;
}
