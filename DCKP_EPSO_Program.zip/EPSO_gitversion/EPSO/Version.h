#ifndef EPSO_VERSION_H
#define EPSO_VERSION_H

inline constexpr const char* kEPSOVersion = "1.0.0";
inline constexpr const char* kEPSOVersionLabel = "EPSO";

#endif // EPSO_VERSION_H
