#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <vector>

#include "Particle.h"

using namespace std;

// Runtime selector set by main.cpp: 1 => Set I, 2 => Set II.
extern int g_dckp_ins_type;

static inline double EffectiveFrequency(const vector<double>* long_term_base,
                                        double long_term_scale,
                                        const vector<int>* short_term,
                                        int item) {
    double f = 0.0;
    if (long_term_base && item >= 0 && item < static_cast<int>(long_term_base->size())) {
        f += (*long_term_base)[item] * long_term_scale;
    }
    if (short_term && item >= 0 && item < static_cast<int>(short_term->size())) {
        f += static_cast<double>((*short_term)[item]);
    }
    return std::max(0.0, f);
}

// Frequency penalty: pi_i(v) = (1 + F_i(v))^{tau_i}.
static inline double FrequencyPenalty(const vector<double>* long_term_base,
                                      double long_term_scale,
                                      const vector<int>* short_term,
                                      int item,
                                      double tau) {
    return std::pow(1.0 + EffectiveFrequency(long_term_base, long_term_scale, short_term, item), tau);
}

// Insertion and exchange point selection.
inline int SelectInsertionPoint(const vector<int>& candidates,
                                const cfGraph& cfg,
                                const vector<double>* long_term_base,
                                double long_term_scale,
                                const vector<int>* short_term,
                                double tau) {
    if (candidates.empty()) throw invalid_argument("SelectInsertionPoint: empty candidate set");

    const double rho = dis01(r_eng);
    double best = -numeric_limits<double>::infinity();
    vector<int> ties;

    for (int pos = 0; pos < static_cast<int>(candidates.size()); ++pos) {
        const int v = candidates[pos];
        const double penalty = FrequencyPenalty(long_term_base, long_term_scale, short_term, v, tau);
        double score = 0.0;
        if (rho <= 0.5) {
            score = cfg.originAdj[v].pwd / penalty;
        } else if (rho < 0.75) {
            score = cfg.originAdj[v].pw / penalty;
        } else {
            score = static_cast<double>(cfg.originAdj[v].profit) / penalty;
        }
        if (score > best) {
            best = score;
            ties.clear();
            ties.push_back(pos);
        } else if (score == best) {
            ties.push_back(pos);
        }
    }

    uniform_int_distribution<int> pick(0, static_cast<int>(ties.size()) - 1);
    return ties[pick(r_eng)];
}

// Deletion point selection.
inline int SelectDeletionPoint(const vector<int>& candidates,
                               const cfGraph& cfg,
                               const vector<double>* long_term_base,
                               double long_term_scale,
                               const vector<int>* short_term,
                               double tau,
                               const vector<double>* topk_pw_sum) {
    if (candidates.empty()) throw invalid_argument("SelectDeletionPoint: empty candidate set");

    const double rho = dis01(r_eng);
    const bool maximize = rho > 0.75;
    double best = maximize ? -numeric_limits<double>::infinity()
                           : numeric_limits<double>::infinity();
    vector<int> ties;

    for (int pos = 0; pos < static_cast<int>(candidates.size()); ++pos) {
        const int v = candidates[pos];
        const double penalty = FrequencyPenalty(long_term_base, long_term_scale, short_term, v, tau);
        double score = 0.0;
        if (rho <= 0.5) {
            score = cfg.originAdj[v].pwd / penalty;
        } else if (rho <= 0.75) {
            score = cfg.originAdj[v].pw / penalty;
        } else {
            const double npw = (topk_pw_sum && v < static_cast<int>(topk_pw_sum->size()))
                                   ? (*topk_pw_sum)[v]
                                   : static_cast<double>(cfg.originAdj[v].degree);
            score = npw * penalty;
        }

        const bool better = maximize ? (score > best) : (score < best);
        if (better) {
            best = score;
            ties.clear();
            ties.push_back(pos);
        } else if (score == best) {
            ties.push_back(pos);
        }
    }

    uniform_int_distribution<int> pick(0, static_cast<int>(ties.size()) - 1);
    return ties[pick(r_eng)];
}

// Stage-dependent allowable deterioration.
inline double AllowedDeterioration(int stage, const cfGraph& cfg) {
    const int q = std::clamp(stage, 0, 2);
    if (g_dckp_ins_type == 1) {
        if (q == 0) return cfg.q1p;
        if (q == 1) return cfg.midp;
        return cfg.q3p;
    }

    const double base = static_cast<double>(cfg.minp) + 20.0 * dis01(r_eng);
    const double ratio = static_cast<double>(q) / 2.0;
    return (0.5 + 0.7 * ratio) * base;
}

// Acceptance rule for refined candidates.
inline bool AcceptRefinedCandidate(double current_fit,
                                   double candidate_fit,
                                   double personal_best_fit,
                                   int stay,
                                   const cfGraph& cfg) {
    const double delta_acc = (g_dckp_ins_type == 1)
                                 ? cfg.q3p
                                 : static_cast<double>(cfg.minp + 20);

    if (candidate_fit > current_fit || candidate_fit >= personal_best_fit - delta_acc) {
        return true;
    }

    const double numerator = current_fit - candidate_fit;
    const double t_base = std::max(1.0, 0.02 * current_fit);
    const double stay_factor = 1.0 + 2.0 * (static_cast<double>(std::min(stay, 200)) / 200.0);
    const double probability = std::exp(-numerator / (t_base * stay_factor));
    return dis01(r_eng) < probability;
}
