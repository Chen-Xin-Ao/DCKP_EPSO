#!/usr/bin/env python3
"""Validate EPSO DCKP solution certificates against Set I and Set II instances.

The validator supports the two instance encodings used by the public DCKP
benchmark and checks every CombN solution stored in an EPSO certificate.
"""

from __future__ import annotations

import argparse
import csv
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


SET1_CATEGORY = "set_I_100"
SET2_CATEGORIES = {
    "C1",
    "C3",
    "C10",
    "C15",
    "R1",
    "R3",
    "R10",
    "R15",
    "sparse_corr",
    "sparse_rand",
}
SKIP_FILENAMES = {"bkv.txt", "filenames.txt"}


@dataclass(frozen=True)
class InstanceData:
    dataset: str
    category: str
    instance_name: str
    path: Path
    n: int
    capacity: int
    profits: tuple[int, ...]
    weights: tuple[int, ...]
    edges: tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class CertificateData:
    dataset: str
    category: str
    instance_key: str
    path: Path
    filename_objective: int | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate EPSO certificates against DCKP Set I and/or Set II instances."
    )
    parser.add_argument(
        "--set1-root",
        type=Path,
        help="Root of DCKP-instances-set I-100. Omit to skip Set I.",
    )
    parser.add_argument(
        "--set2-root",
        type=Path,
        help="Root of DCKP-instances-set II-6240. Omit to skip Set II.",
    )
    parser.add_argument(
        "--cert-root",
        type=Path,
        required=True,
        help=(
            "Root of EPSO certificates. It may directly contain C1/.../set_I_100, "
            "or contain one EPSO_DCKP6340sol_certificates subdirectory."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("epso_certificate_validation_output"),
        help="Directory for CSV reports (default: ./epso_certificate_validation_output).",
    )
    parser.add_argument(
        "--categories",
        nargs="*",
        default=None,
        help="Optional Set II categories to validate, e.g. --categories C1 C15 sparse_rand.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with status 1 if any certificate is missing, malformed, infeasible, or inconsistent.",
    )
    args = parser.parse_args()
    if args.set1_root is None and args.set2_root is None:
        parser.error("Specify at least one of --set1-root or --set2-root.")
    if args.categories:
        invalid = sorted(set(args.categories) - SET2_CATEGORIES)
        if invalid:
            parser.error(f"Unknown Set II categories: {', '.join(invalid)}")
    return args


def canonical_instance_key(category: str, name: str) -> str:
    """Map source and certificate file names to one category-scoped key."""
    value = (name or "").strip().strip('"').replace("\\", "/").split("/")[-1]
    if category in {"sparse_corr", "sparse_rand"}:
        if value.endswith(".dat"):
            value = value[:-4]
        if value.startswith("test_"):
            value = value[5:]
    elif value.endswith(".txt"):
        # Set I certificate names carry a .txt suffix. Removing one final
        # suffix also keeps source and certificate keys aligned for Set II.
        value = value[:-4]
    return value


def to_int(value: str | None) -> int | None:
    if value is None or not value.strip():
        return None
    try:
        return int(value.strip())
    except ValueError:
        try:
            return int(round(float(value.strip())))
        except ValueError:
            return None


def parse_set1_instance(path: Path, instance_name: str) -> InstanceData:
    values = [int(token) for token in re.findall(r"-?\d+", path.read_text(encoding="utf-8", errors="ignore"))]
    if len(values) < 3:
        raise ValueError("Incomplete Set I header")

    n, edge_count, capacity = values[:3]
    expected = 3 + 2 * n + 2 * edge_count
    if len(values) != expected:
        raise ValueError(f"Token count {len(values)} does not match expected {expected}")

    profits = tuple(values[3 : 3 + n])
    weights = tuple(values[3 + n : 3 + 2 * n])
    edge_values = values[3 + 2 * n :]
    raw_edges = list(zip(edge_values[::2], edge_values[1::2]))
    if any(u < 1 or v < 1 or u > n or v > n for u, v in raw_edges):
        raise ValueError("Set I conflict edge has an index outside 1..n")

    # Set I encodes both certificate item numbers and edges as 1-based.
    return InstanceData(
        dataset="Set1",
        category=SET1_CATEGORY,
        instance_name=instance_name,
        path=path,
        n=n,
        capacity=capacity,
        profits=profits,
        weights=weights,
        edges=tuple((u - 1, v - 1) for u, v in raw_edges),
    )


def parse_set2_instance(path: Path, category: str, instance_name: str) -> InstanceData:
    text = path.read_text(encoding="utf-8", errors="ignore")
    n_match = re.search(r"param\s+n\s*:=\s*(\d+)\s*;", text)
    # Some benchmark files omit the semicolon after this declaration.
    capacity_match = re.search(r"param\s+c\s*:=\s*(\d+)\s*;?", text)
    item_block_match = re.search(r"param\s*:\s*V\s*:\s*p\s+w\s*:=\s*(.*?)\s*;", text, re.S)
    edge_block_match = re.search(r"set\s+E\s*:=\s*(.*?)\s*;", text, re.S)
    if not all((n_match, capacity_match, item_block_match, edge_block_match)):
        raise ValueError("Unable to parse Set II n/c/V/E blocks")

    n = int(n_match.group(1))
    capacity = int(capacity_match.group(1))
    item_map: dict[int, tuple[int, int]] = {}
    for line in item_block_match.group(1).splitlines():
        fields = line.split()
        if not fields:
            continue
        if len(fields) != 3:
            raise ValueError(f"Invalid item row: {line!r}")
        index, profit, weight = map(int, fields)
        item_map[index] = (profit, weight)

    missing = sorted(set(range(n)) - set(item_map))
    if missing:
        raise ValueError(f"Missing item rows for indices: {missing[:10]}")

    edges: list[tuple[int, int]] = []
    for line in edge_block_match.group(1).splitlines():
        fields = line.split()
        if not fields:
            continue
        if len(fields) != 2:
            raise ValueError(f"Invalid conflict row: {line!r}")
        u, v = map(int, fields)
        if not (0 <= u < n and 0 <= v < n):
            raise ValueError(f"Conflict edge index outside 0..n-1: {(u, v)}")
        edges.append((u, v))

    return InstanceData(
        dataset="Set2",
        category=category,
        instance_name=instance_name,
        path=path,
        n=n,
        capacity=capacity,
        profits=tuple(item_map[index][0] for index in range(n)),
        weights=tuple(item_map[index][1] for index in range(n)),
        edges=tuple(edges),
    )


def discover_instances(
    set1_root: Path | None,
    set2_root: Path | None,
    categories: set[str] | None,
) -> dict[tuple[str, str, str], tuple[Path, str]]:
    instances: dict[tuple[str, str, str], tuple[Path, str]] = {}

    def add(dataset: str, category: str, path: Path) -> None:
        key = (dataset, category, canonical_instance_key(category, path.name))
        if key in instances:
            raise ValueError(f"Duplicate instance key: {'|'.join(key)}")
        instances[key] = (path, path.name)

    if set1_root is not None:
        if not set1_root.is_dir():
            raise FileNotFoundError(f"Set I root does not exist: {set1_root}")
        for path in sorted(set1_root.rglob("*")):
            if path.is_file() and path.name not in SKIP_FILENAMES:
                add("Set1", SET1_CATEGORY, path)

    if set2_root is not None:
        if not set2_root.is_dir():
            raise FileNotFoundError(f"Set II root does not exist: {set2_root}")
        selected_categories = categories or SET2_CATEGORIES
        for category_dir in sorted(set2_root.iterdir()):
            category = category_dir.name
            if not category_dir.is_dir() or category not in selected_categories:
                continue
            for path in sorted(category_dir.iterdir()):
                if path.is_file() and path.name not in SKIP_FILENAMES:
                    add("Set2", category, path)

    return instances


def resolve_certificate_root(path: Path) -> Path:
    if not path.is_dir():
        raise FileNotFoundError(f"Certificate root does not exist: {path}")
    nested = path / "EPSO_DCKP6340sol_certificates"
    if nested.is_dir() and not (path / "C1").is_dir():
        return nested
    return path


def discover_certificates(
    cert_root: Path,
    include_set1: bool,
    include_categories: set[str],
) -> tuple[dict[tuple[str, str, str], CertificateData], list[dict[str, object]]]:
    certificates: dict[tuple[str, str, str], CertificateData] = {}
    issues: list[dict[str, object]] = []

    for category_dir in sorted(cert_root.iterdir()):
        if not category_dir.is_dir():
            continue
        if category_dir.name == SET1_CATEGORY and include_set1:
            dataset, category = "Set1", SET1_CATEGORY
        elif category_dir.name in include_categories:
            dataset, category = "Set2", category_dir.name
        else:
            continue

        for path in sorted(category_dir.iterdir()):
            if not path.is_file() or "_value=" not in path.name:
                continue
            raw_name, value_text = path.name.rsplit("_value=", 1)
            key = (dataset, category, canonical_instance_key(category, raw_name))
            if key in certificates:
                issues.append(
                    {
                        "Issue": "duplicate_certificate_key",
                        "Path": str(path),
                        "Key": "|".join(key),
                    }
                )
                continue
            certificates[key] = CertificateData(
                dataset=dataset,
                category=category,
                instance_key=key[2],
                path=path,
                filename_objective=to_int(value_text),
            )
    return certificates, issues


COMB_RE = re.compile(
    r"Comb(?P<id>\d+)\s*:\s*\[(?P<items>[^\]]*)\]\s*Profit\s*=\s*(?P<profit>-?\d+)\s*Weight\s*=\s*(?P<weight>-?\d+)",
    re.S,
)


def parse_epso_certificate(path: Path) -> tuple[int | None, list[tuple[int, list[int], int | None, int | None]]]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    best_profit_match = re.search(r"BestProfit\s*:\s*(-?\d+)", text)
    solutions: list[tuple[int, list[int], int | None, int | None]] = []
    for match in COMB_RE.finditer(text):
        item_text = match.group("items").strip()
        # EPSO CombN lists benchmark item IDs, which are 1-based in both sets.
        items = [int(value) - 1 for value in item_text.split()] if item_text else []
        solutions.append(
            (
                int(match.group("id")),
                items,
                to_int(match.group("profit")),
                to_int(match.group("weight")),
            )
        )
    if not solutions:
        raise ValueError("No CombN solution entries found")
    return to_int(best_profit_match.group(1)) if best_profit_match else None, solutions


def validate_solution(instance: InstanceData, selected: Iterable[int]) -> dict[str, object]:
    raw_selected = list(selected)
    invalid_indices = sorted({index for index in raw_selected if index < 0 or index >= instance.n})
    valid_selected = [index for index in raw_selected if 0 <= index < instance.n]
    selected_set = set(valid_selected)
    duplicate_count = len(valid_selected) - len(selected_set)
    profit = sum(instance.profits[index] for index in selected_set)
    weight = sum(instance.weights[index] for index in selected_set)
    conflicts = [(u, v) for u, v in instance.edges if u in selected_set and v in selected_set]

    capacity_ok = weight <= instance.capacity
    feasible = not invalid_indices and duplicate_count == 0 and capacity_ok and not conflicts
    return {
        "SelectedCount": len(selected_set),
        "ComputedProfit": profit,
        "ComputedWeight": weight,
        "CapacityOK": int(capacity_ok),
        "ConflictViolationCount": len(conflicts),
        "ConflictPreview": ";".join(f"{u}-{v}" for u, v in conflicts[:10]),
        "InvalidIndexCount": len(invalid_indices),
        "InvalidIndexPreview": ",".join(map(str, invalid_indices[:10])),
        "DuplicateSelectionCount": duplicate_count,
        "Feasible": int(feasible),
    }


DETAIL_FIELDS = [
    "Dataset",
    "Category",
    "Instance",
    "CertificateFile",
    "CertificatePath",
    "SolutionID",
    "InstanceN",
    "SelectedCount",
    "ComputedProfit",
    "FilenameObjective",
    "ReportedProfit",
    "ProfitMatchesReported",
    "HeaderBestProfit",
    "ProfitMatchesHeaderBest",
    "ComputedWeight",
    "ReportedWeight",
    "WeightMatchesReported",
    "Capacity",
    "CapacityOK",
    "ConflictViolationCount",
    "ConflictPreview",
    "InvalidIndexCount",
    "InvalidIndexPreview",
    "DuplicateSelectionCount",
    "Feasible",
    "InstancePath",
]


def write_csv(path: Path, rows: Iterable[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    cert_root = resolve_certificate_root(args.cert_root)
    selected_categories = set(args.categories) if args.categories else SET2_CATEGORIES
    instances = discover_instances(args.set1_root, args.set2_root, selected_categories)
    certificates, issues = discover_certificates(
        cert_root,
        include_set1=args.set1_root is not None,
        include_categories=selected_categories if args.set2_root is not None else set(),
    )

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    detail_path = output_dir / "solution_validation_detail.csv"
    certificate_summary_path = output_dir / "certificate_validation_summary.csv"
    invalid_path = output_dir / "invalid_or_inconsistent_solutions.csv"
    issues_path = output_dir / "matching_and_parse_issues.csv"

    summary: dict[tuple[str, str], Counter] = defaultdict(Counter)
    processed_keys: set[tuple[str, str, str]] = set()

    with (
        detail_path.open("w", encoding="utf-8-sig", newline="") as detail_handle,
        certificate_summary_path.open("w", encoding="utf-8-sig", newline="") as certificate_handle,
        invalid_path.open("w", encoding="utf-8-sig", newline="") as invalid_handle,
    ):
        detail_writer = csv.DictWriter(detail_handle, fieldnames=DETAIL_FIELDS)
        invalid_writer = csv.DictWriter(invalid_handle, fieldnames=DETAIL_FIELDS)
        certificate_writer = csv.DictWriter(
            certificate_handle,
            fieldnames=[
                "Dataset",
                "Category",
                "Instance",
                "CertificateFile",
                "CertificatePath",
                "SolutionCount",
                "FeasibleSolutionCount",
                "InfeasibleSolutionCount",
                "CapacityViolationSolutionCount",
                "ConflictViolationSolutionCount",
                "MalformedSolutionCount",
                "ObjectiveMismatchSolutionCount",
                "WeightMismatchSolutionCount",
                "AllSolutionsFeasible",
                "InstancePath",
            ],
        )
        detail_writer.writeheader()
        invalid_writer.writeheader()
        certificate_writer.writeheader()

        for key, (instance_path, instance_name) in sorted(instances.items()):
            dataset, category, instance_key = key
            try:
                instance = (
                    parse_set1_instance(instance_path, instance_name)
                    if dataset == "Set1"
                    else parse_set2_instance(instance_path, category, instance_name)
                )
            except Exception as exc:
                issues.append(
                    {
                        "Issue": "instance_parse_error",
                        "Path": str(instance_path),
                        "Key": f"{'|'.join(key)}: {exc}",
                    }
                )
                continue

            certificate = certificates.get(key)
            if certificate is None:
                issues.append(
                    {
                        "Issue": "missing_certificate_for_instance",
                        "Path": str(instance_path),
                        "Key": "|".join(key),
                    }
                )
                continue
            processed_keys.add(key)
            category_counter = summary[(dataset, category)]
            category_counter["CertificateCount"] += 1

            try:
                header_best_profit, combinations = parse_epso_certificate(certificate.path)
            except Exception as exc:
                category_counter["CertificateParseErrorCount"] += 1
                issues.append(
                    {
                        "Issue": "certificate_parse_error",
                        "Path": str(certificate.path),
                        "Key": f"{'|'.join(key)}: {exc}",
                    }
                )
                continue

            certificate_counter = Counter()
            for combination_id, selected, reported_profit, reported_weight in combinations:
                validation = validate_solution(instance, selected)
                computed_profit = int(validation["ComputedProfit"])
                computed_weight = int(validation["ComputedWeight"])
                row = {
                    "Dataset": dataset,
                    "Category": category,
                    "Instance": instance.instance_name,
                    "CertificateFile": certificate.path.name,
                    "CertificatePath": str(certificate.path),
                    "SolutionID": f"Comb{combination_id}",
                    "InstanceN": instance.n,
                    **validation,
                    "FilenameObjective": "" if certificate.filename_objective is None else certificate.filename_objective,
                    "ReportedProfit": "" if reported_profit is None else reported_profit,
                    "ProfitMatchesReported": "" if reported_profit is None else int(computed_profit == reported_profit),
                    "HeaderBestProfit": "" if header_best_profit is None else header_best_profit,
                    "ProfitMatchesHeaderBest": "" if header_best_profit is None else int(computed_profit == header_best_profit),
                    "ReportedWeight": "" if reported_weight is None else reported_weight,
                    "WeightMatchesReported": "" if reported_weight is None else int(computed_weight == reported_weight),
                    "Capacity": instance.capacity,
                    "InstancePath": str(instance.path),
                }
                detail_writer.writerow(row)
                category_counter["SolutionCount"] += 1
                certificate_counter["SolutionCount"] += 1

                if row["Feasible"]:
                    category_counter["FeasibleSolutionCount"] += 1
                    certificate_counter["FeasibleSolutionCount"] += 1
                else:
                    category_counter["InfeasibleSolutionCount"] += 1
                    certificate_counter["InfeasibleSolutionCount"] += 1
                if not row["CapacityOK"]:
                    category_counter["CapacityViolationSolutionCount"] += 1
                    certificate_counter["CapacityViolationSolutionCount"] += 1
                if int(row["ConflictViolationCount"]) > 0:
                    category_counter["ConflictViolationSolutionCount"] += 1
                    certificate_counter["ConflictViolationSolutionCount"] += 1
                malformed = int(row["InvalidIndexCount"]) > 0 or int(row["DuplicateSelectionCount"]) > 0
                if malformed:
                    category_counter["MalformedSolutionCount"] += 1
                    certificate_counter["MalformedSolutionCount"] += 1
                objective_mismatch = row["ProfitMatchesReported"] == 0 or row["ProfitMatchesHeaderBest"] == 0
                if objective_mismatch:
                    category_counter["ObjectiveMismatchSolutionCount"] += 1
                    certificate_counter["ObjectiveMismatchSolutionCount"] += 1
                if row["WeightMatchesReported"] == 0:
                    category_counter["WeightMismatchSolutionCount"] += 1
                    certificate_counter["WeightMismatchSolutionCount"] += 1
                if not row["Feasible"] or objective_mismatch or row["WeightMatchesReported"] == 0:
                    invalid_writer.writerow(row)

            certificate_writer.writerow(
                {
                    "Dataset": dataset,
                    "Category": category,
                    "Instance": instance.instance_name,
                    "CertificateFile": certificate.path.name,
                    "CertificatePath": str(certificate.path),
                    "SolutionCount": certificate_counter["SolutionCount"],
                    "FeasibleSolutionCount": certificate_counter["FeasibleSolutionCount"],
                    "InfeasibleSolutionCount": certificate_counter["InfeasibleSolutionCount"],
                    "CapacityViolationSolutionCount": certificate_counter["CapacityViolationSolutionCount"],
                    "ConflictViolationSolutionCount": certificate_counter["ConflictViolationSolutionCount"],
                    "MalformedSolutionCount": certificate_counter["MalformedSolutionCount"],
                    "ObjectiveMismatchSolutionCount": certificate_counter["ObjectiveMismatchSolutionCount"],
                    "WeightMismatchSolutionCount": certificate_counter["WeightMismatchSolutionCount"],
                    "AllSolutionsFeasible": int(
                        certificate_counter["SolutionCount"] > 0
                        and certificate_counter["InfeasibleSolutionCount"] == 0
                    ),
                    "InstancePath": str(instance.path),
                }
            )

    for key, certificate in sorted(certificates.items()):
        if key not in processed_keys:
            issues.append(
                {
                    "Issue": "certificate_without_matching_instance",
                    "Path": str(certificate.path),
                    "Key": "|".join(key),
                }
            )

    summary_rows: list[dict[str, object]] = []
    for (dataset, category), counter in sorted(summary.items()):
        summary_rows.append(
            {
                "Dataset": dataset,
                "Category": category,
                "CertificateCount": counter["CertificateCount"],
                "SolutionCount": counter["SolutionCount"],
                "FeasibleSolutionCount": counter["FeasibleSolutionCount"],
                "InfeasibleSolutionCount": counter["InfeasibleSolutionCount"],
                "CapacityViolationSolutionCount": counter["CapacityViolationSolutionCount"],
                "ConflictViolationSolutionCount": counter["ConflictViolationSolutionCount"],
                "MalformedSolutionCount": counter["MalformedSolutionCount"],
                "ObjectiveMismatchSolutionCount": counter["ObjectiveMismatchSolutionCount"],
                "WeightMismatchSolutionCount": counter["WeightMismatchSolutionCount"],
                "CertificateParseErrorCount": counter["CertificateParseErrorCount"],
            }
        )
    write_csv(
        output_dir / "validation_summary_by_category.csv",
        summary_rows,
        [
            "Dataset",
            "Category",
            "CertificateCount",
            "SolutionCount",
            "FeasibleSolutionCount",
            "InfeasibleSolutionCount",
            "CapacityViolationSolutionCount",
            "ConflictViolationSolutionCount",
            "MalformedSolutionCount",
            "ObjectiveMismatchSolutionCount",
            "WeightMismatchSolutionCount",
            "CertificateParseErrorCount",
        ],
    )
    write_csv(issues_path, issues, ["Issue", "Path", "Key"])

    infeasible = sum(row["InfeasibleSolutionCount"] for row in summary_rows)
    malformed = sum(row["MalformedSolutionCount"] for row in summary_rows)
    objective_mismatches = sum(row["ObjectiveMismatchSolutionCount"] for row in summary_rows)
    weight_mismatches = sum(row["WeightMismatchSolutionCount"] for row in summary_rows)
    parse_errors = sum(row["CertificateParseErrorCount"] for row in summary_rows)
    print(f"Instances discovered: {len(instances)}")
    print(f"EPSO certificates discovered: {len(certificates)}")
    print(f"Validation summary rows: {len(summary_rows)}")
    print(f"Issues: {len(issues)}")
    print(f"Infeasible solutions: {infeasible}")
    print(f"Malformed solutions: {malformed}")
    print(f"Objective mismatches: {objective_mismatches}")
    print(f"Weight mismatches: {weight_mismatches}")
    print(f"Certificate parse errors: {parse_errors}")
    print(f"Output directory: {output_dir.resolve()}")

    if args.strict and (
        issues
        or infeasible
        or malformed
        or objective_mismatches
        or weight_mismatches
        or parse_errors
    ):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
