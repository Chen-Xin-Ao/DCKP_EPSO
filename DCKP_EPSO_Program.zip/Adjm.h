#ifndef EPSO_ADJM_H
#define EPSO_ADJM_H

#include <vector>

using namespace std;

struct Vertex {
    int id = 0;
    int degree = 0;
    int support = 0;
    int profit = 0;
    int weight = 0;
    double pw = 0.0;   // profit / weight
    double pwd = 0.0;  // profit / (weight * (degree + 1))
    double wd = 0.0;
    double pd = 0.0;
    vector<int> adjList;
};

class Adjm {
public:
    vector<Vertex> vertices;

    Adjm(int n, const int profitArray[], const int weightArray[]) : vertices(n) {
        for (int i = 0; i < n; ++i) {
            vertices[i].id = i;
            vertices[i].profit = profitArray[i];
            vertices[i].weight = weightArray[i];
            vertices[i].pw = weightArray[i] > 0
                                 ? static_cast<double>(profitArray[i]) / static_cast<double>(weightArray[i])
                                 : 0.0;
        }
    }

    void addEdge(int u, int v) {
        vertices[u].adjList.push_back(v);
        vertices[v].adjList.push_back(u);
        ++vertices[u].degree;
        ++vertices[v].degree;
    }
};

#endif // EPSO_ADJM_H
