# EPSO DCKP Certificate Validator

This script validates EPSO solution certificates for the DCKP benchmark.
It supports both benchmark instance encodings:

- Set I: `DCKP-instances-set I-100`
- Set II: `DCKP-instances-set II-6240`

It validates every `CombN` solution recorded in each EPSO certificate.
No third-party Python packages are required.

## Requirements

- Python 3.10 or later
- EPSO certificates stored by category, using names such as:
  - `1I1_value=2567`
  - `BPPC_1_0_1.txt_0.1_value=210`
  - `test_1000_1000_r0.001-0.dat_value=7755`

## Run

Validate both benchmark sets:

```powershell
python validate_epso_certificates.py `
  --set1-root ./DCKP-instances-set-I-100 `
  --set2-root ./DCKP-instances-set-II-6240 `
  --cert-root ./EPSO_DCKP6340sol_certificates `
  --output-dir ./validation_output `
  --strict
```

Validate only Set I:

```powershell
python validate_epso_certificates.py `
  --set1-root ./DCKP-instances-set-I-100 `
  --cert-root ./EPSO_DCKP6340sol_certificates
```

Validate selected Set II classes only:

```powershell
python validate_epso_certificates.py `
  --set2-root ./DCKP-instances-set-II-6240 `
  --cert-root ./EPSO_DCKP6340sol_certificates `
  --categories C15 sparse_rand
```

`--cert-root` can point either to the directory that directly contains
`C1`, `C3`, ..., `set_I_100`, or to its parent directory when that parent
contains a single `EPSO_DCKP6340sol_certificates` child directory.

## Checks

For every EPSO `CombN` solution, the validator recomputes:

- selected items
- total profit
- total weight
- capacity feasibility
- all conflict-edge violations

It also checks the computed profit and weight against the values recorded in
the certificate. Set I uses 1-based conflict edges; Set II uses 0-based
conflict edges. EPSO `CombN` item identifiers are interpreted as 1-based in
both sets.

## Output

The output directory contains these CSV files:

- `validation_summary_by_category.csv`: aggregate counts by dataset and class
- `certificate_validation_summary.csv`: one row per certificate
- `solution_validation_detail.csv`: one row per `CombN` solution
- `invalid_or_inconsistent_solutions.csv`: only infeasible or inconsistent solutions
- `matching_and_parse_issues.csv`: missing matches, duplicate keys, or parser errors

An empty `invalid_or_inconsistent_solutions.csv` and an empty
`matching_and_parse_issues.csv` mean every parsed certificate solution passed
all checks.

## Exit Status

Without `--strict`, the script writes reports and exits with status `0` even
when it finds issues. With `--strict`, it exits with status `1` if it finds a
missing/malformed certificate, an infeasible solution, or a certificate parse
error. This mode is suitable for CI.
