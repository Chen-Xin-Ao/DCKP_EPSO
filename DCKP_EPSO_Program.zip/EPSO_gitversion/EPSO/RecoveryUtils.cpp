#include <algorithm>
#include <cmath>
#include <numeric>
#include <unordered_set>
#include <vector>

#include "Particle.h"

using namespace std;

static inline vector<int> WeightedSampleRareFirst(const vector<int>& candidates,
                                                  const vector<double>& frequency,
                                                  int k,
                                                  double tau = 1.0) {
    vector<int> out;
    if (k <= 0 || candidates.empty()) return out;
    k = std::min(k, static_cast<int>(candidates.size()));
    if (k == static_cast<int>(candidates.size())) return candidates;

    // Weighted sampling without replacement.
    vector<pair<double, int>> keys;
    keys.reserve(candidates.size());
    for (int v : candidates) {
        const double f = (v >= 0 && v < static_cast<int>(frequency.size()))
                             ? std::max(0.0, frequency[v])
                             : 0.0;
        const double weight = 1.0 / std::pow(1.0 + f, tau);
        const double u = std::max(1e-12, dis01(r_eng));
        keys.emplace_back(std::log(u) / weight, v);
    }
    auto cmp = [](const auto& a, const auto& b) { return a.first > b.first; };
    std::nth_element(keys.begin(), keys.begin() + (k - 1), keys.end(), cmp);
    keys.resize(k);
    out.reserve(k);
    for (const auto& kv : keys) out.push_back(kv.second);
    return out;
}

// Apply population-guided proposal adjustment.
void ApplyPGSA(vector<double>& proposal,
               const vector<Particle>& particles,
               int global_no_improvement) {
    // Use a 50-iteration post-improvement window.
    if (global_no_improvement >= 50 || particles.empty()) return;

    vector<vector<int>> pattern_pool;
    pattern_pool.reserve(particles.size() * 2);
    for (const auto& p : particles) {
        pattern_pool.push_back(p.selected);
        pattern_pool.push_back(SelectedFromPosition(p.number_best));
    }
    if (pattern_pool.size() < 2) return;

    uniform_int_distribution<int> pick(0, static_cast<int>(pattern_pool.size()) - 1);
    int a = pick(r_eng);
    int b = a;
    while (b == a) b = pick(r_eng);

    const vector<int>& g1 = pattern_pool[a];
    const vector<int>& g2 = pattern_pool[b];

    vector<int> original_positive;
    original_positive.reserve(proposal.size());
    vector<char> was_positive(proposal.size(), 0);
    for (int k = 0; k < static_cast<int>(proposal.size()); ++k) {
        if (proposal[k] > 0.0) {
            original_positive.push_back(k);
            was_positive[k] = 1;
            proposal[k] = -std::abs(proposal[k]);
        }
    }

    vector<char> preserved(proposal.size(), 0);
    auto preserve_pattern = [&](const vector<int>& pattern) {
        for (int k : pattern) {
            if (k >= 0 && k < static_cast<int>(proposal.size()) && was_positive[k]) {
                proposal[k] = std::abs(proposal[k]);
                preserved[k] = 1;
            }
        }
    };
    preserve_pattern(g1);
    preserve_pattern(g2);

    vector<int> remaining;
    remaining.reserve(original_positive.size());
    for (int k : original_positive) {
        if (!preserved[k]) remaining.push_back(k);
    }

    const int restore_bound = std::max(static_cast<int>(std::floor(0.3 * original_positive.size())), 15);
    const int restore_count = std::min(static_cast<int>(remaining.size()), restore_bound);
    std::shuffle(remaining.begin(), remaining.end(), r_eng);
    for (int i = 0; i < restore_count; ++i) {
        const int k = remaining[i];
        proposal[k] = std::abs(proposal[k]);
    }
}

// Aggregate the population-level long-term frequency.
vector<double> AggregateLongTermFrequency(const vector<vector<double>>& freq_base,
                                          const vector<double>& freq_scale,
                                          int n) {
    vector<double> aggregate(n, 0.0);
    const int m = std::min(freq_base.size(), freq_scale.size());
    for (int j = 0; j < m; ++j) {
        for (int v = 0; v < n && v < static_cast<int>(freq_base[j].size()); ++v) {
            aggregate[v] += freq_base[j][v] * freq_scale[j];
        }
    }
    return aggregate;
}

// Perturb one stagnated particle using the inverse set.
void PerturbByInverseSet(Particle& particle,
                         const vector<double>& population_long_term_frequency) {
    const int n = static_cast<int>(particle.number.size());
    unordered_set<int> excluded(particle.selected.begin(), particle.selected.end());
    const vector<int> personal_best = SelectedFromPosition(particle.number_best);
    excluded.insert(personal_best.begin(), personal_best.end());

    vector<int> inverse_set;
    inverse_set.reserve(n);
    for (int v = 0; v < n; ++v) {
        if (!excluded.count(v)) inverse_set.push_back(v);
        // Reconstruct the perturbed trajectory from the inverse set: excluded
        // items remain on the unselected (negative) side.
        particle.number[v] = dis_negative(r_eng);
    }

    const int target_size = std::min(static_cast<int>(personal_best.size()),
                                     static_cast<int>(inverse_set.size()));
    const vector<int> chosen = WeightedSampleRareFirst(inverse_set,
                                                        population_long_term_frequency,
                                                        target_size);
    for (int v : chosen) particle.number[v] = dis_positive(r_eng);
}

// Construct one new particle position from the population-level inverse set.
vector<double> GenerateExpansionPosition(const vector<Particle>& particles,
                                         const vector<double>& population_long_term_frequency) {
    if (particles.empty()) return {};
    const int n = static_cast<int>(particles.front().number.size());
    vector<double> result(n);
    for (double& x : result) x = dis_negative(r_eng);

    unordered_set<int> excluded;
    for (const auto& p : particles) {
        excluded.insert(p.selected.begin(), p.selected.end());
        const vector<int> pbest = SelectedFromPosition(p.number_best);
        excluded.insert(pbest.begin(), pbest.end());
    }

    vector<int> inverse_set;
    inverse_set.reserve(n);
    for (int v = 0; v < n; ++v) {
        if (!excluded.count(v)) inverse_set.push_back(v);
    }

    // Set the expansion cardinality from the incumbent solution-size scale.
    const int reference_size = static_cast<int>(particles.front().selected.size());
    const int target_size = std::min(static_cast<int>(inverse_set.size()),
                                     reference_size + static_cast<int>(dis01(r_eng) * 10.0));
    const vector<int> chosen = WeightedSampleRareFirst(inverse_set,
                                                        population_long_term_frequency,
                                                        target_size);
    for (int v : chosen) result[v] = dis_positive(r_eng);
    return result;
}

// Periodic repair-control coefficient.
double RepairControlProbability(int stay) {
    constexpr int period = 50;
    const int d = ((stay % period) + period) % period;
    const double pi = std::acos(-1.0);
    const double rho = 0.5 + 0.4 * std::sin(2.0 * pi * (static_cast<double>(d) - 15.0) / 50.0);
    return std::clamp(rho, 0.1, 0.9);
}
