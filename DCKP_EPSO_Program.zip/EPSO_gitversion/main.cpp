/**
 * EPSO (single-instance runner)
 *
 * Usage:
 *   ./EPSO InsName Seed InsType
 *     InsType: "1" for Set I, "2" for Set II
 *
 * Notes:
 * - Benchmark files may be supplied by path.
 * - Cut-off rule: min(1.5*n, 1000) s for Set I and
 *   min(1.5*n, 600) s for Set II.
 * - Output: a single file named "<InsName>_<time>_<result>" in the current folder.
 */
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <sstream>
#include <string>
#include <vector>

#include "Adjm.h"
#include "cfGraph.h"


// Runtime instance type selector used by the inlined algorithm code.
// 1 => Set I behavior, 2 => Set II behavior.
int g_dckp_ins_type = 0;

#include "EPSO/EPSO.cpp"

using namespace std;

extern double g_best_time;
static double ComputeTimeLimitSecForType(int numItems, int ins_type) {
    const double cap = (ins_type == 1) ? 1000.0 : 600.0;
    return std::min(1.5 * static_cast<double>(numItems), cap);
}

static void ComputeProfitQuartiles(const int* arr, int size, double& q1, double& med, double& q3) {
    vector<int> vec(arr, arr + size);
    sort(vec.begin(), vec.end());
    auto quantile = [&](double q) -> double {
        if (vec.empty()) return 0.0;
        double pos = (vec.size() - 1) * q;
        size_t i0 = (size_t)floor(pos);
        size_t i1 = (size_t)ceil(pos);
        if (i0 == i1) return (double)vec[i0];
        double w = pos - (double)i0;
        return (1.0 - w) * (double)vec[i0] + w * (double)vec[i1];
    };
    q1 = quantile(0.25);
    med = quantile(0.50);
    q3 = quantile(0.75);
}

struct InstanceData {
    int n = 0;
    int m = 0;
    int capacity = 0;
    vector<int> profit;
    vector<int> weight;
    vector<pair<int, int>> edges; // 0-based
    double density = 0.0;
};

static bool ReadSetI(const string& path, InstanceData& out) {
    ifstream file(path);
    if (!file.is_open()) return false;

    int n = 0, m = 0, C = 0;
    file >> n >> m >> C;
    if (!file || n <= 0 || m < 0 || C < 0) return false;

    vector<int> profit(n), weight(n);
    for (int i = 0; i < n; ++i) {
        file >> profit[i];
        if (!file) return false;
    }
    for (int i = 0; i < n; ++i) {
        file >> weight[i];
        if (!file) return false;
    }

    vector<pair<int, int>> edges;
    edges.reserve((size_t)m);
    for (int i = 0; i < m; ++i) {
        int u, v;
        file >> u >> v;
        if (!file) return false;
        // Set I edges are 1-based; convert to 0-based.
        --u;
        --v;
        if (u < 0 || v < 0 || u >= n || v >= n) return false;
        edges.emplace_back(u, v);
    }

    out.n = n;
    out.m = m;
    out.capacity = C;
    out.profit = std::move(profit);
    out.weight = std::move(weight);
    out.edges = std::move(edges);
    out.density = (n > 1) ? ((double)m * 2.0 / ((double)n * (double)(n - 1))) : 0.0;
    return true;
}

static bool ReadSetII(const string& path, InstanceData& out) {
    ifstream file(path);
    if (!file.is_open()) return false;

    int n = 0, C = 0;
    vector<int> profit, weight;
    vector<pair<int, int>> edges;

    string line;
    int item_count = 0;
    bool got_items = false;
    while (getline(file, line)) {
        if (line.find("param n") != string::npos) {
            size_t pos = line.find(":=");
            if (pos != string::npos) n = stoi(line.substr(pos + 2));
        } else if (line.find("param c") != string::npos) {
            size_t pos = line.find(":=");
            if (pos != string::npos) C = stoi(line.substr(pos + 2));
        } else if (line.find("param : V : p w :=") != string::npos) {
            if (n <= 0) return false;
            profit.assign(n, 0);
            weight.assign(n, 0);
            item_count = 0;
            while (getline(file, line)) {
                if (line == ";" || line.empty()) break;
                istringstream iss(line);
                int idx, p, w;
                if (!(iss >> idx >> p >> w)) return false;
                if (idx < 0 || idx >= n) return false; // Set II is 0-based
                profit[idx] = p;
                weight[idx] = w;
                item_count++;
            }
            if (item_count != n) return false;
            got_items = true;
        } else if (line.find("set E :=") != string::npos) {
            if (!got_items) return false;
            while (getline(file, line)) {
                if (line == ";") break;
                if (line.empty()) continue;
                istringstream iss(line);
                int u, v;
                if (!(iss >> u >> v)) return false;
                if (u < 0 || v < 0 || u >= n || v >= n) return false;
                edges.emplace_back(u, v); // already 0-based
            }
            break;
        }
    }

    out.n = n;
    out.capacity = C;
    out.profit = std::move(profit);
    out.weight = std::move(weight);
    out.edges = std::move(edges);
    out.m = (int)out.edges.size();
    out.density = (n > 1) ? ((double)out.m * 2.0 / ((double)n * (double)(n - 1))) : 0.0;
    return (out.n > 0 && out.capacity >= 0 && (int)out.profit.size() == out.n && (int)out.weight.size() == out.n);
}

static int RunOne(const string& ins_path, unsigned int seed_input, int ins_type) {
    const string ins_name = std::filesystem::path(ins_path).filename().string();
    const int item_index_base = (ins_type == 1) ? 1 : 0; // follow benchmark style: Set I uses 1-based, Set II uses 0-based

    cout << "Instance: " << ins_name << ", Seed = " << seed_input << ", InsType = " << ins_type
         << endl;

    InstanceData data;
    bool ok = false;
    if (ins_type == 1) ok = ReadSetI(ins_path, data);
    else if (ins_type == 2) ok = ReadSetII(ins_path, data);
    if (!ok) {
        cerr << "Failed to read instance: " << ins_name << " (InsType=" << ins_type << ")" << endl;
        return 2;
    }

    g_dckp_ins_type = ins_type;

    set_seed(seed_input);

    const double time_limit_sec = ComputeTimeLimitSecForType(data.n, ins_type);
    cout << "CutoffTime = " << fixed << setprecision(3) << time_limit_sec << "s" << endl;

    long long sumProfit = 0;
    int minp = std::numeric_limits<int>::max();
    int maxp = std::numeric_limits<int>::min();
    int minw = std::numeric_limits<int>::max();
    int maxw = 0;
    for (int i = 0; i < data.n; ++i) {
        sumProfit += data.profit[i];
        minp = std::min(minp, data.profit[i]);
        maxp = std::max(maxp, data.profit[i]);
        minw = std::min(minw, data.weight[i]);
        maxw = std::max(maxw, data.weight[i]);
    }
    double avg_profit = (data.n > 0) ? ((double)sumProfit / (double)data.n) : 0.0;
    double q1p = 0.0, midp = 0.0, q3p = 0.0;
    ComputeProfitQuartiles(data.profit.data(), data.n, q1p, midp, q3p);

    Adjm adjm(data.n, data.profit.data(), data.weight.data());
    cfGraph cfg(data.n, avg_profit, minp, maxp, q1p, midp, q3p);
    cfg.getDensity(data.density);
    cfg.minw = minw;
    cfg.maxw = maxw;

    for (const auto& e : data.edges) {
        adjm.addEdge(e.first, e.second);
        cfg.addEdges(e.first, e.second);
    }
    cfg.getVertices(adjm.vertices);

    int initial_popsize = std::max(cfg.n / 100, 5);
    initial_popsize = std::min(initial_popsize, 10);
    int end_iter = 0;
    vector<Particle> best_array = RunEPSO(data.capacity, cfg, initial_popsize, time_limit_sec, end_iter);

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3) << g_best_time;
    std::string time_str = oss.str();

    const string out_name = ins_name + "_" + time_str + "_" + to_string(best_array[0].fit);
    ofstream outfile(out_name);
    if (!outfile.is_open()) {
        cerr << "Failed to open output file: " << out_name << endl;
        cfg.release();
        return 3;
    }

    outfile << "CodeVersion: " << kEPSOVersion << "\n";
    outfile << "Instance: " << ins_name << "\n";
    outfile << "BestProfit: " << best_array[0].fit << "\n";
    outfile << "BestWeight: " << best_array[0].weight << "\n";
    outfile << "Time: " << time_str << "\n";
    outfile << "All best combinations (same profit):" << "\n";
    outfile << "ItemIndexBase: " << item_index_base << "\n";

    for (size_t i = 0; i < best_array.size(); ++i) {
        vector<int> sel = best_array[i].selected;
        sort(sel.begin(), sel.end());
        outfile << "Comb" << i << ": [";
        for (size_t j = 0; j < sel.size(); ++j) {
            outfile << (sel[j] + item_index_base);
            if (j + 1 < sel.size()) outfile << " ";
        }
        outfile << "]"
                << " Profit=" << best_array[i].fit
                << " Weight=" << best_array[i].weight
                << "\n";
    }

    outfile.close();

    cout << "BestProfit = " << best_array[0].fit << ", BestWeight = " << best_array[0].weight
         << ", BestTime = " << time_str << "s" << endl;
    cout << "OutputFile: " << out_name << endl;

    cfg.release();
    return 0;
}

int main(int argc, char* argv[]) {
   
    if (argc == 4 && std::string(argv[1]) == "--check-instance") {
        const std::string path = argv[2];
        const int ins_type = std::stoi(argv[3]);
        InstanceData data;
        bool ok = false;
        if (ins_type == 1) ok = ReadSetI(path, data);
        else if (ins_type == 2) ok = ReadSetII(path, data);
        if (!ok) {
            cerr << "Failed to parse instance: " << path << " (InsType=" << ins_type << ")" << endl;
            return 2;
        }
        cout << "Parsed instance: n=" << data.n << ", m=" << data.m
             << ", capacity=" << data.capacity << ", density=" << std::setprecision(12)
             << data.density << endl;
        return 0;
    }
    if (argc == 2 && (std::string(argv[1]) == "--help" || std::string(argv[1]) == "-h")) {
        cout << "Usage:\n  ./EPSO InsName Seed InsType\n"
             << "  InsType: 1 for Set I, 2 for Set II\n"
             << "  ./EPSO --check-instance InsName InsType\n"
             << "  ./EPSO --version\n";
        return 0;
    }
    if (argc != 4) {
        cerr << "Usage:\n  ./EPSO InsName Seed InsType\n"
             << "  InsType: 1 for Set I, 2 for Set II\n";
        return 1;
    }

    const string ins = argv[1];
    const unsigned int seed = (unsigned int)stoul(argv[2]);
    const int insType = stoi(argv[3]);
    if (insType != 1 && insType != 2) {
        cerr << "Invalid InsType: " << insType << " (expected 1 or 2)" << endl;
        return 1;
    }

    return RunOne(ins, seed, insType);
}
